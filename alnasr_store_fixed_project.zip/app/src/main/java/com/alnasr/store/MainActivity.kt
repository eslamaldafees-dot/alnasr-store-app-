package com.alnasr.store
import android.os.Bundle
import androidx.activity.ComponentActivity
class MainActivity: ComponentActivity(){
 override fun onCreate(b: Bundle?){super.onCreate(b)}
}