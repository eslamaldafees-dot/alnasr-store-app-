rootProject.name="AlnasrStore"
include(":app")
